<!--  Header
 * Author: Rakhi Dayanandan
-->
<!doctype html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />


	<title>ATTENDENCE MANAGMENT SYSTEM</title>
	<link rel="stylesheet" href="../css/style.css" type="text/css">
	
	
</head>
<body class="bi">

<div class="menubar">
<ul>
<li><a href="login.php">Home</a></li>
<li><a href="contact_us.php">Contact Us</a></li>
<li><a href="logout.php">Log Out</a>
</ul>
</div>





	
	
	
	
